"use client";

import { Bell, BellRing } from "lucide-react";
import { useWallet } from "@/context/WalletProvider";

export default function NotificationsPage() {
  const { notifications, markAllRead, unreadCount } = useWallet();

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-ink/50 dark:text-white/50">
          {unreadCount > 0 ? `${unreadCount} unread` : "You're all caught up"}
        </p>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="text-sm font-medium text-nova-400">
            Mark all as read
          </button>
        )}
      </div>

      <div className="rounded-2xl border border-ink/5 bg-white shadow-soft dark:border-white/5 dark:bg-nova-900">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center">
            <Bell size={28} className="text-ink/20 dark:text-white/20" />
            <p className="text-sm text-ink/40 dark:text-white/40">No notifications yet.</p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className="flex items-start gap-3 border-b border-ink/5 px-5 py-4 last:border-0 dark:border-white/5"
            >
              <span
                className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                  n.read
                    ? "bg-ink/5 text-ink/40 dark:bg-white/5 dark:text-white/40"
                    : "bg-nova-400/10 text-nova-400"
                }`}
              >
                {n.read ? <Bell size={15} /> : <BellRing size={15} />}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-medium text-ink dark:text-white">
                    {n.title}
                  </p>
                  <span className="shrink-0 text-xs text-ink/40 dark:text-white/40">{n.time}</span>
                </div>
                <p className="mt-0.5 text-sm text-ink/55 dark:text-white/55">{n.body}</p>
              </div>
              {!n.read && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-nova-400" />}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
