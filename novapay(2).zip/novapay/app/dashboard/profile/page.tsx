"use client";

import { ShieldCheck, Pencil } from "lucide-react";
import { currentUser } from "@/lib/mockData";
import FormField from "@/components/FormField";

export default function ProfilePage() {
  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-6 flex flex-col items-center gap-3 rounded-2xl border border-ink/5 bg-white p-6 text-center shadow-soft dark:border-white/5 dark:bg-nova-900 sm:flex-row sm:text-left">
        <span className="relative flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-nova-gradient text-lg font-semibold text-white">
          {currentUser.avatarInitials}
          <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-white text-nova-400 dark:border-nova-900 dark:bg-nova-900">
            <Pencil size={11} />
          </span>
        </span>
        <div className="flex-1">
          <p className="font-display text-lg font-semibold text-ink dark:text-white">
            {currentUser.name}
          </p>
          <p className="text-sm text-ink/50 dark:text-white/50">{currentUser.tag}</p>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1.5 text-xs font-medium text-emerald-500">
          <ShieldCheck size={13} /> KYC verified
        </span>
      </div>

      <div className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <h3 className="mb-4 font-display text-sm font-semibold text-ink dark:text-white">
          Personal details
        </h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField id="fullName" label="Full name" defaultValue={currentUser.name} readOnly />
          <FormField id="profileEmail" label="Email" defaultValue={currentUser.email} readOnly />
          <FormField id="phone" label="Phone number" defaultValue={currentUser.phone} readOnly />
          <FormField id="accNum" label="Account number" defaultValue={currentUser.accountNumber} readOnly />
        </div>
        <button className="mt-5 rounded-xl bg-nova-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-nova-700 dark:bg-nova-400 dark:hover:bg-nova-300">
          Edit profile
        </button>
      </div>
    </div>
  );
}
