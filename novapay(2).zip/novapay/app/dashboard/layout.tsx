"use client";

import { useState } from "react";
import { usePathname } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/Topbar";

const titles: Record<string, string> = {
  "/dashboard": "Overview",
  "/dashboard/send": "Send money",
  "/dashboard/receive": "Receive money",
  "/dashboard/add-money": "Add money",
  "/dashboard/withdraw": "Withdraw",
  "/dashboard/transactions": "Transactions",
  "/dashboard/card": "Your card",
  "/dashboard/notifications": "Notifications",
  "/dashboard/profile": "Profile",
  "/dashboard/settings": "Settings",
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const title = titles[pathname] ?? "NovaPay";

  return (
    <div className="flex min-h-screen bg-mist dark:bg-nova-950">
      <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <div className="flex min-h-screen flex-1 flex-col">
        <Topbar onMenuClick={() => setMenuOpen(true)} title={title} />
        <main className="flex-1 px-5 py-6 md:px-8 md:py-8">{children}</main>
      </div>
    </div>
  );
}
