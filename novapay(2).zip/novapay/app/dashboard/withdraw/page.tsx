"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { Loader2, ArrowUpFromLine } from "lucide-react";
import { useWallet } from "@/context/WalletProvider";
import { formatMoney } from "@/lib/mockData";
import FormField from "@/components/FormField";
import SuccessState from "@/components/SuccessState";

const banks = [
  { id: "gtb", label: "GTBank", sub: "•••• 4821" },
  { id: "zenith", label: "Zenith Bank", sub: "•••• 1190" },
  { id: "moniepoint", label: "Moniepoint", sub: "•••• 3306" },
];

export default function WithdrawPage() {
  const { balance, simulate } = useWallet();
  const [bank, setBank] = useState(banks[0].id);
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const value = Number(amount);
    if (!value || value <= 0) return setError("Enter a valid amount.");
    if (value > balance) return setError("Insufficient balance for this withdrawal.");
    setError("");
    setLoading(true);
    const bankLabel = banks.find((b) => b.id === bank)?.label ?? "Bank";
    setTimeout(() => {
      simulate("withdraw", value, `${bankLabel} account`);
      setLoading(false);
      setDone(true);
    }, 900);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-md">
        <SuccessState
          title="Withdrawn to"
          amount={formatMoney(Number(amount))}
          detail={`${banks.find((b) => b.id === bank)?.label} — funds arrive in 5–30 minutes (simulated).`}
          actions={
            <>
              <button
                onClick={() => {
                  setDone(false);
                  setAmount("");
                }}
                className="rounded-xl border border-ink/10 px-5 py-2.5 text-sm font-medium text-ink dark:border-white/10 dark:text-white"
              >
                Withdraw again
              </button>
              <Link
                href="/dashboard"
                className="rounded-xl bg-nova-900 px-5 py-2.5 text-sm font-medium text-white dark:bg-nova-400"
              >
                Back to overview
              </Link>
            </>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md">
      <p className="mb-6 text-sm text-ink/50 dark:text-white/50">
        Available balance:{" "}
        <span className="ledger font-semibold text-ink dark:text-white">
          {formatMoney(balance)}
        </span>
      </p>
      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-5 rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900"
      >
        <FormField
          id="withdraw-amount"
          label="Amount (₦)"
          type="number"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />

        <div>
          <p className="mb-2 text-sm font-medium text-ink/70 dark:text-white/70">
            Withdraw to
          </p>
          <div className="flex flex-col gap-2">
            {banks.map(({ id, label, sub }) => (
              <button
                type="button"
                key={id}
                onClick={() => setBank(id)}
                className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left transition ${
                  bank === id ? "border-nova-400 bg-nova-400/5" : "border-ink/10 dark:border-white/10"
                }`}
              >
                <span className="text-sm font-medium text-ink dark:text-white">{label}</span>
                <span className="ledger text-xs text-ink/45 dark:text-white/45">{sub}</span>
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="flex items-center justify-center gap-2 rounded-xl bg-nova-900 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-nova-700 disabled:opacity-70 dark:bg-nova-400 dark:hover:bg-nova-300"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <ArrowUpFromLine size={16} />}
          {loading ? "Processing…" : "Withdraw"}
        </button>
      </form>
    </div>
  );
}
