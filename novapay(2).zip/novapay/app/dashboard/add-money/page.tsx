"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { Loader2, PlusCircle, Landmark, CreditCard, Building2 } from "lucide-react";
import { useWallet } from "@/context/WalletProvider";
import { formatMoney } from "@/lib/mockData";
import FormField from "@/components/FormField";
import SuccessState from "@/components/SuccessState";

const sources = [
  { id: "card", label: "Debit card", sub: "•••• 4471", icon: CreditCard },
  { id: "bank", label: "Bank transfer", sub: "GTBank •••4821", icon: Landmark },
  { id: "moniepoint", label: "Moniepoint", sub: "Instant transfer", icon: Building2 },
];

export default function AddMoneyPage() {
  const { simulate } = useWallet();
  const [source, setSource] = useState(sources[0].id);
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const value = Number(amount);
    if (!value || value <= 0) return setError("Enter a valid amount.");
    setError("");
    setLoading(true);
    const sourceLabel = sources.find((s) => s.id === source)?.label ?? "Funding source";
    setTimeout(() => {
      simulate("add-money", value, sourceLabel);
      setLoading(false);
      setDone(true);
    }, 900);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-md">
        <SuccessState
          title="Added to your wallet"
          amount={formatMoney(Number(amount))}
          detail="Your balance has been updated instantly (simulated)."
          actions={
            <>
              <button
                onClick={() => {
                  setDone(false);
                  setAmount("");
                }}
                className="rounded-xl border border-ink/10 px-5 py-2.5 text-sm font-medium text-ink dark:border-white/10 dark:text-white"
              >
                Add more
              </button>
              <Link
                href="/dashboard"
                className="rounded-xl bg-nova-900 px-5 py-2.5 text-sm font-medium text-white dark:bg-nova-400"
              >
                Back to overview
              </Link>
            </>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md">
      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-5 rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900"
      >
        <FormField
          id="add-amount"
          label="Amount (₦)"
          type="number"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />

        <div>
          <p className="mb-2 text-sm font-medium text-ink/70 dark:text-white/70">
            Funding source
          </p>
          <div className="flex flex-col gap-2">
            {sources.map(({ id, label, sub, icon: Icon }) => (
              <button
                type="button"
                key={id}
                onClick={() => setSource(id)}
                className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-left transition ${
                  source === id
                    ? "border-nova-400 bg-nova-400/5"
                    : "border-ink/10 dark:border-white/10"
                }`}
              >
                <Icon size={18} className="text-nova-400" />
                <div>
                  <p className="text-sm font-medium text-ink dark:text-white">{label}</p>
                  <p className="text-xs text-ink/45 dark:text-white/45">{sub}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="flex items-center justify-center gap-2 rounded-xl bg-nova-900 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-nova-700 disabled:opacity-70 dark:bg-nova-400 dark:hover:bg-nova-300"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <PlusCircle size={16} />}
          {loading ? "Processing…" : "Add money"}
        </button>
      </form>
    </div>
  );
}
