"use client";

import Link from "next/link";
import { ArrowRight, Download, PlusCircle, Send, ArrowUpFromLine, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { useWallet } from "@/context/WalletProvider";
import { currentUser, formatMoney } from "@/lib/mockData";
import QuickAction from "@/components/QuickAction";
import VirtualCard from "@/components/VirtualCard";
import BalanceChart from "@/components/BalanceChart";
import TransactionRow from "@/components/TransactionRow";
import DemoBadge from "@/components/DemoBadge";

export default function DashboardOverview() {
  const { balance, transactions } = useWallet();
  const [hideBalance, setHideBalance] = useState(false);

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <DemoBadge />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Balance card */}
        <div className="animate-fade-up rounded-3xl bg-nova-gradient p-6 text-white shadow-card lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white/60">
                Welcome back, {currentUser.name.split(" ")[0]}
              </p>
              <div className="mt-2 flex items-center gap-3">
                <p className="ledger text-3xl font-semibold md:text-4xl">
                  {hideBalance ? "₦••••••.••" : formatMoney(balance)}
                </p>
                <button
                  onClick={() => setHideBalance((h) => !h)}
                  className="text-white/50 hover:text-white"
                  aria-label="Toggle balance visibility"
                >
                  {hideBalance ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <p className="mt-1 text-xs text-white/40">
                Account •••• {currentUser.accountNumber.slice(-4)}
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-4 gap-2">
            <QuickActionLight href="/dashboard/send" icon={Send} label="Send" />
            <QuickActionLight href="/dashboard/receive" icon={Download} label="Receive" />
            <QuickActionLight href="/dashboard/add-money" icon={PlusCircle} label="Add" />
            <QuickActionLight href="/dashboard/withdraw" icon={ArrowUpFromLine} label="Withdraw" />
          </div>

          <div className="mt-6 border-t border-white/10 pt-4">
            <p className="mb-1 text-xs text-white/50">Balance trend</p>
            <BalanceChart />
          </div>
        </div>

        {/* Card preview */}
        <div className="animate-fade-up [animation-delay:100ms]">
          <VirtualCard />
          <Link
            href="/dashboard/card"
            className="mt-4 flex items-center justify-center gap-1.5 rounded-xl border border-ink/10 py-2.5 text-sm font-medium text-ink/70 dark:border-white/10 dark:text-white/70"
          >
            Manage card <ArrowRight size={14} />
          </Link>
        </div>
      </div>

      {/* Quick actions grid (mobile-friendly, restated for smaller screens) */}
      <div className="grid grid-cols-4 gap-3 lg:hidden">
        <QuickAction href="/dashboard/send" icon={Send} label="Send" />
        <QuickAction href="/dashboard/receive" icon={Download} label="Receive" />
        <QuickAction href="/dashboard/add-money" icon={PlusCircle} label="Add money" />
        <QuickAction href="/dashboard/withdraw" icon={ArrowUpFromLine} label="Withdraw" />
      </div>

      {/* Recent transactions */}
      <div className="animate-fade-up rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900 [animation-delay:150ms]">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-ink dark:text-white">
            Recent transactions
          </h2>
          <Link href="/dashboard/transactions" className="text-sm font-medium text-nova-400">
            View all
          </Link>
        </div>
        <div>
          {transactions.slice(0, 5).map((txn) => (
            <TransactionRow key={txn.id} txn={txn} />
          ))}
        </div>
      </div>
    </div>
  );
}

function QuickActionLight({
  href,
  icon: Icon,
  label,
}: {
  href: string;
  icon: typeof Send;
  label: string;
}) {
  return (
    <Link
      href={href}
      className="flex flex-col items-center gap-1.5 rounded-xl bg-white/10 py-3 text-center transition hover:bg-white/15"
    >
      <Icon size={16} />
      <span className="text-[11px] font-medium">{label}</span>
    </Link>
  );
}
