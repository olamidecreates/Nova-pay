"use client";

import { useState } from "react";
import { Snowflake, Eye, EyeOff, Lock } from "lucide-react";
import VirtualCard from "@/components/VirtualCard";
import { currentUser } from "@/lib/mockData";
import DemoBadge from "@/components/DemoBadge";

export default function CardPage() {
  const [frozen, setFrozen] = useState(false);
  const [reveal, setReveal] = useState(false);

  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-6">
      <DemoBadge />
      <VirtualCard frozen={frozen} />

      <div className="grid w-full grid-cols-2 gap-3">
        <button
          onClick={() => setFrozen((f) => !f)}
          className={`flex items-center justify-center gap-2 rounded-xl border py-3 text-sm font-medium transition ${
            frozen
              ? "border-nova-400 bg-nova-400/10 text-nova-400"
              : "border-ink/10 text-ink/70 dark:border-white/10 dark:text-white/70"
          }`}
        >
          <Snowflake size={16} />
          {frozen ? "Unfreeze card" : "Freeze card"}
        </button>
        <button
          onClick={() => setReveal((r) => !r)}
          className="flex items-center justify-center gap-2 rounded-xl border border-ink/10 py-3 text-sm font-medium text-ink/70 dark:border-white/10 dark:text-white/70"
        >
          {reveal ? <EyeOff size={16} /> : <Eye size={16} />}
          {reveal ? "Hide details" : "Reveal details"}
        </button>
      </div>

      {reveal && (
        <div className="w-full rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
          <Row label="Card number" value="5399 8231 0042 4471" />
          <Row label="Expiry" value={currentUser.cardExpiry} />
          <Row label="CVV" value="•••" />
          <p className="mt-2 flex items-center gap-1.5 text-xs text-ink/40 dark:text-white/40">
            <Lock size={11} /> Simulated card — not a real payment instrument.
          </p>
        </div>
      )}

      <div className="w-full rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <h3 className="mb-3 font-display text-sm font-semibold text-ink dark:text-white">
          Spending limits
        </h3>
        <LimitBar label="Daily limit" used={62000} total={500000} />
        <LimitBar label="Monthly limit" used={310000} total={2000000} />
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-ink/5 py-2.5 last:border-0 dark:border-white/5">
      <span className="text-sm text-ink/50 dark:text-white/50">{label}</span>
      <span className="ledger text-sm font-medium text-ink dark:text-white">{value}</span>
    </div>
  );
}

function LimitBar({ label, used, total }: { label: string; used: number; total: number }) {
  const pct = Math.min(100, Math.round((used / total) * 100));
  return (
    <div className="mb-4 last:mb-0">
      <div className="mb-1.5 flex justify-between text-xs text-ink/50 dark:text-white/50">
        <span>{label}</span>
        <span className="ledger">
          ₦{used.toLocaleString()} / ₦{total.toLocaleString()}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-ink/5 dark:bg-white/10">
        <div
          className="h-full rounded-full bg-nova-gradient transition-all"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
