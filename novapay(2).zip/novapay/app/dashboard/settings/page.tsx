"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LogOut } from "lucide-react";
import { useTheme } from "@/context/ThemeProvider";
import { useWallet } from "@/context/WalletProvider";

function ToggleRow({
  label,
  sub,
  checked,
  onChange,
}: {
  label: string;
  sub: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <div className="flex items-center justify-between border-b border-ink/5 py-4 last:border-0 dark:border-white/5">
      <div>
        <p className="text-sm font-medium text-ink dark:text-white">{label}</p>
        <p className="text-xs text-ink/45 dark:text-white/45">{sub}</p>
      </div>
      <button
        onClick={onChange}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${
          checked ? "bg-nova-400" : "bg-ink/15 dark:bg-white/15"
        }`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
            checked ? "translate-x-5" : "translate-x-0.5"
          }`}
        />
      </button>
    </div>
  );
}

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const { logout } = useWallet();
  const router = useRouter();
  const [push, setPush] = useState(true);
  const [email, setEmail] = useState(true);
  const [biometric, setBiometric] = useState(false);
  const [twoFA, setTwoFA] = useState(true);

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <section className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <h3 className="mb-1 font-display text-sm font-semibold text-ink dark:text-white">
          Appearance
        </h3>
        <ToggleRow
          label="Dark mode"
          sub="Switch between light and dark theme"
          checked={theme === "dark"}
          onChange={toggleTheme}
        />
      </section>

      <section className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <h3 className="mb-1 font-display text-sm font-semibold text-ink dark:text-white">
          Notifications
        </h3>
        <ToggleRow
          label="Push notifications"
          sub="Get notified of transfers and account activity"
          checked={push}
          onChange={() => setPush((v) => !v)}
        />
        <ToggleRow
          label="Email alerts"
          sub="Weekly summaries and important updates"
          checked={email}
          onChange={() => setEmail((v) => !v)}
        />
      </section>

      <section className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <h3 className="mb-1 font-display text-sm font-semibold text-ink dark:text-white">
          Security
        </h3>
        <ToggleRow
          label="Two-factor authentication"
          sub="Require a code at login for extra security"
          checked={twoFA}
          onChange={() => setTwoFA((v) => !v)}
        />
        <ToggleRow
          label="Biometric login"
          sub="Use fingerprint or face unlock on this device"
          checked={biometric}
          onChange={() => setBiometric((v) => !v)}
        />
        <button className="mt-3 text-sm font-medium text-nova-400">Change password</button>
      </section>

      <button
        onClick={() => {
          logout();
          router.push("/login");
        }}
        className="flex w-full items-center justify-center gap-2 rounded-xl border border-rose-500/20 py-3 text-sm font-semibold text-rose-500 transition hover:bg-rose-500/5"
      >
        <LogOut size={16} />
        Log out
      </button>
    </div>
  );
}
