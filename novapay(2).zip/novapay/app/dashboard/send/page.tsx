"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { Loader2, Send } from "lucide-react";
import { useWallet } from "@/context/WalletProvider";
import { formatMoney } from "@/lib/mockData";
import FormField from "@/components/FormField";
import SuccessState from "@/components/SuccessState";

const contacts = [
  { name: "Chidinma Okafor", tag: "@chidinma" },
  { name: "Toyoola Ventures", tag: "@toyoola" },
  { name: "Femi Adebayo", tag: "@femi" },
  { name: "Yoola's Bite", tag: "@yoolasbite" },
];

export default function SendMoneyPage() {
  const { balance, simulate } = useWallet();
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const value = Number(amount);
    if (!recipient) return setError("Enter a recipient name, tag, or account number.");
    if (!value || value <= 0) return setError("Enter a valid amount.");
    if (value > balance) return setError("Insufficient balance for this transfer.");
    setError("");
    setLoading(true);
    setTimeout(() => {
      simulate("send", value, recipient, note || undefined);
      setLoading(false);
      setDone(true);
    }, 900);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-md">
        <SuccessState
          title="Sent to"
          amount={formatMoney(Number(amount))}
          detail={`${recipient} will see this instantly (simulated).`}
          actions={
            <>
              <button
                onClick={() => {
                  setDone(false);
                  setRecipient("");
                  setAmount("");
                  setNote("");
                }}
                className="rounded-xl border border-ink/10 px-5 py-2.5 text-sm font-medium text-ink dark:border-white/10 dark:text-white"
              >
                Send another
              </button>
              <Link
                href="/dashboard"
                className="rounded-xl bg-nova-900 px-5 py-2.5 text-sm font-medium text-white dark:bg-nova-400"
              >
                Back to overview
              </Link>
            </>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md">
      <p className="mb-6 text-sm text-ink/50 dark:text-white/50">
        Available balance:{" "}
        <span className="ledger font-semibold text-ink dark:text-white">
          {formatMoney(balance)}
        </span>
      </p>

      <div className="mb-6 flex gap-3 overflow-x-auto pb-1">
        {contacts.map((c) => (
          <button
            key={c.tag}
            onClick={() => setRecipient(c.name)}
            className="flex shrink-0 flex-col items-center gap-1.5"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-nova-gradient text-sm font-semibold text-white">
              {c.name
                .split(" ")
                .map((w) => w[0])
                .slice(0, 2)
                .join("")}
            </span>
            <span className="text-[11px] text-ink/60 dark:text-white/60">{c.name.split(" ")[0]}</span>
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4 rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <FormField
          id="recipient"
          label="Recipient (name, @tag, or account number)"
          placeholder="e.g. Chidinma Okafor"
          value={recipient}
          onChange={(e) => setRecipient(e.target.value)}
        />
        <FormField
          id="amount"
          label="Amount (₦)"
          type="number"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <FormField
          id="note"
          label="Note (optional)"
          placeholder="What's this for?"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-nova-900 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-nova-700 disabled:opacity-70 dark:bg-nova-400 dark:hover:bg-nova-300"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          {loading ? "Sending…" : "Send money"}
        </button>
      </form>
    </div>
  );
}
