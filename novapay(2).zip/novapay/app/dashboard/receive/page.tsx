"use client";

import { useState } from "react";
import { Copy, Check, QrCode } from "lucide-react";
import { currentUser } from "@/lib/mockData";
import DemoBadge from "@/components/DemoBadge";

function CopyRow({ label, value }: { label: string; value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="flex items-center justify-between border-b border-ink/5 py-3 last:border-0 dark:border-white/5">
      <div>
        <p className="text-xs text-ink/45 dark:text-white/45">{label}</p>
        <p className="ledger mt-0.5 text-sm font-medium text-ink dark:text-white">{value}</p>
      </div>
      <button
        onClick={() => {
          navigator.clipboard?.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        }}
        className="flex h-8 w-8 items-center justify-center rounded-lg text-ink/50 hover:bg-ink/5 dark:text-white/50 dark:hover:bg-white/5"
        aria-label={`Copy ${label}`}
      >
        {copied ? <Check size={15} className="text-emerald-500" /> : <Copy size={15} />}
      </button>
    </div>
  );
}

export default function ReceiveMoneyPage() {
  return (
    <div className="mx-auto max-w-md">
      <DemoBadge className="mb-6" />
      <div className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <div className="flex flex-col items-center gap-3 border-b border-ink/5 pb-6 dark:border-white/5">
          <span className="flex h-32 w-32 items-center justify-center rounded-2xl bg-nova-100 text-nova-400 dark:bg-nova-800">
            <QrCode size={72} strokeWidth={1.2} />
          </span>
          <p className="text-sm text-ink/50 dark:text-white/50">
            Scan to send money to {currentUser.tag}
          </p>
        </div>

        <div className="pt-2">
          <CopyRow label="NovaPay tag" value={currentUser.tag} />
          <CopyRow label="Account number" value={currentUser.accountNumber} />
          <CopyRow label="Account name" value={currentUser.name} />
          <CopyRow label="Bank" value="NovaPay Microfinance Bank" />
        </div>
      </div>

      <p className="mt-4 text-center text-xs text-ink/40 dark:text-white/40">
        Share your tag or account number with anyone to receive money instantly.
        This is a simulated account for demonstration only.
      </p>
    </div>
  );
}
