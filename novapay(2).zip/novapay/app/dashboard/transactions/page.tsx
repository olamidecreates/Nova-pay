"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { useWallet } from "@/context/WalletProvider";
import { TransactionType } from "@/lib/mockData";
import TransactionRow from "@/components/TransactionRow";

const filters: { id: TransactionType | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "send", label: "Sent" },
  { id: "receive", label: "Received" },
  { id: "add-money", label: "Added" },
  { id: "withdraw", label: "Withdrawn" },
];

export default function TransactionsPage() {
  const { transactions } = useWallet();
  const [filter, setFilter] = useState<TransactionType | "all">("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return transactions.filter((t) => {
      const matchesType = filter === "all" || t.type === filter;
      const matchesQuery =
        query.trim() === "" ||
        t.counterparty.toLowerCase().includes(query.toLowerCase()) ||
        t.note?.toLowerCase().includes(query.toLowerCase());
      return matchesType && matchesQuery;
    });
  }, [transactions, filter, query]);

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40 dark:text-white/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search transactions"
            className="w-full rounded-xl border border-ink/10 bg-white py-2.5 pl-9 pr-3 text-sm outline-none focus:border-nova-400 focus:ring-2 focus:ring-nova-400/20 dark:border-white/10 dark:bg-nova-900 dark:text-white"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium transition ${
                filter === f.id
                  ? "bg-nova-900 text-white dark:bg-nova-400"
                  : "border border-ink/10 text-ink/60 dark:border-white/10 dark:text-white/60"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        {filtered.length === 0 ? (
          <p className="py-10 text-center text-sm text-ink/40 dark:text-white/40">
            No transactions match your search.
          </p>
        ) : (
          filtered.map((txn) => <TransactionRow key={txn.id} txn={txn} />)
        )}
      </div>
    </div>
  );
}
