"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { CheckCircle2, Loader2 } from "lucide-react";
import AuthShell from "@/components/AuthShell";
import FormField from "@/components/FormField";

export default function ForgotPasswordPage() {
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [email, setEmail] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
    }, 800);
  };

  return (
    <AuthShell
      eyebrow="Account recovery"
      title="Reset your password"
      subtitle="We'll simulate sending a reset link to your inbox."
    >
      {sent ? (
        <div className="flex flex-col items-start gap-3 rounded-xl border border-nova-400/20 bg-nova-100 p-5 dark:bg-nova-900">
          <CheckCircle2 className="text-nova-400" size={22} />
          <p className="text-sm text-ink dark:text-white">
            If an account exists for <span className="font-semibold">{email}</span>,
            a reset link has been sent. (Simulated — no email is actually sent.)
          </p>
          <Link href="/login" className="text-sm font-semibold text-nova-400">
            Back to login
          </Link>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <FormField
            id="reset-email"
            label="Email address"
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-nova-900 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-nova-700 disabled:opacity-70 dark:bg-nova-400 dark:hover:bg-nova-300"
          >
            {loading && <Loader2 size={16} className="animate-spin" />}
            {loading ? "Sending…" : "Send reset link"}
          </button>
        </form>
      )}
      <p className="mt-6 text-center text-sm text-ink/50 dark:text-white/50">
        Remembered it?{" "}
        <Link href="/login" className="font-semibold text-nova-400">
          Log in
        </Link>
      </p>
    </AuthShell>
  );
}
