"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import AuthShell from "@/components/AuthShell";
import FormField from "@/components/FormField";
import { useWallet } from "@/context/WalletProvider";

export default function LoginPage() {
  const router = useRouter();
  const { login } = useWallet();
  const [email, setEmail] = useState("olamide@novapay.demo");
  const [password, setPassword] = useState("novapay-demo");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      login();
      setLoading(false);
      router.push("/dashboard");
    }, 700);
  };

  return (
    <AuthShell
      eyebrow="Welcome back"
      title="Log in to NovaPay"
      subtitle="Demo credentials are pre-filled — just hit continue."
    >
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <FormField
          id="email"
          label="Email address"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <FormField
          id="password"
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-ink/60 dark:text-white/60">
            <input type="checkbox" defaultChecked className="rounded border-ink/20" />
            Remember me
          </label>
          <Link href="/forgot-password" className="font-medium text-nova-400">
            Forgot password?
          </Link>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-nova-900 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-nova-700 disabled:opacity-70 dark:bg-nova-400 dark:hover:bg-nova-300"
        >
          {loading && <Loader2 size={16} className="animate-spin" />}
          {loading ? "Signing in…" : "Continue"}
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-ink/50 dark:text-white/50">
        New to NovaPay?{" "}
        <Link href="/signup" className="font-semibold text-nova-400">
          Create an account
        </Link>
      </p>
    </AuthShell>
  );
}
