import Link from "next/link";
import { ArrowRight, Send, ShieldCheck, Sparkles, Wallet } from "lucide-react";
import Logo from "@/components/Logo";
import DemoBadge from "@/components/DemoBadge";

const features = [
  {
    icon: Send,
    title: "Move money instantly",
    body: "Send, receive, top up, and withdraw in a few taps — every transfer simulated in real time.",
  },
  {
    icon: Wallet,
    title: "One wallet, full clarity",
    body: "A live balance, a virtual card, and a ledger of every transaction, laid out the way a statement should read.",
  },
  {
    icon: ShieldCheck,
    title: "Built like it's real",
    body: "Login, KYC-style profile, notifications, and an admin console — the full shape of a production fintech product.",
  },
];

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-mist dark:bg-nova-950">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Logo />
        <div className="flex items-center gap-3">
          <Link
            href="/login"
            className="rounded-full px-4 py-2 text-sm font-medium text-ink/70 hover:text-ink dark:text-white/70 dark:hover:text-white"
          >
            Log in
          </Link>
          <Link
            href="/signup"
            className="rounded-full bg-nova-900 px-4 py-2 text-sm font-medium text-white shadow-soft transition hover:bg-nova-700 dark:bg-nova-400 dark:hover:bg-nova-300"
          >
            Open an account
          </Link>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl gap-12 px-6 pb-20 pt-10 md:grid-cols-2 md:items-center md:pt-16">
        <div className="animate-fade-up">
          <DemoBadge />
          <h1 className="mt-6 font-display text-4xl font-bold leading-[1.05] tracking-tight text-ink dark:text-white md:text-6xl">
            Money, moved with
            <span className="block text-nova-400">quiet confidence.</span>
          </h1>
          <p className="mt-5 max-w-md text-base text-ink/60 dark:text-white/60 md:text-lg">
            NovaPay is a concept wallet built to show what a premium, modern
            fintech product feels like end to end — from onboarding to an
            admin dashboard.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link
              href="/signup"
              className="group inline-flex items-center gap-2 rounded-full bg-nova-900 px-6 py-3 text-sm font-semibold text-white shadow-card transition hover:bg-nova-700 dark:bg-nova-400 dark:hover:bg-nova-300"
            >
              Get started free
              <ArrowRight
                size={16}
                className="transition group-hover:translate-x-1"
              />
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-full border border-ink/10 px-6 py-3 text-sm font-semibold text-ink dark:border-white/15 dark:text-white"
            >
              View live demo
            </Link>
          </div>
          <p className="mt-4 text-xs text-ink/40 dark:text-white/40">
            No signup required to explore — demo credentials are pre-filled on
            the login screen.
          </p>
        </div>

        <div className="relative animate-fade-up [animation-delay:150ms]">
          <div className="relative mx-auto aspect-[16/10] w-full max-w-md rounded-3xl bg-nova-gradient p-7 text-white shadow-card">
            <div className="card-sheen-anim absolute inset-0 rounded-3xl bg-card-sheen bg-[length:200%_100%]" />
            <div className="relative flex h-full flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="font-display text-sm tracking-wide text-white/80">
                  NovaPay Black
                </span>
                <Sparkles size={18} className="text-gold-light" />
              </div>
              <div>
                <p className="ledger text-2xl tracking-widest text-white/90 md:text-3xl">
                  5399 82•• •••• 4471
                </p>
                <div className="mt-4 flex items-center justify-between text-sm text-white/70">
                  <span>IPAYE T. OLAMIDE</span>
                  <span className="ledger">09/29</span>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute -bottom-6 -left-4 hidden rounded-2xl bg-white p-4 shadow-card dark:bg-nova-900 sm:block">
            <p className="text-xs text-ink/50 dark:text-white/50">Wallet balance</p>
            <p className="ledger text-xl font-semibold text-ink dark:text-white">
              ₦482,650.75
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid gap-5 md:grid-cols-3">
          {features.map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="rounded-2xl border border-ink/5 bg-white p-6 shadow-soft dark:border-white/5 dark:bg-nova-900"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-nova-100 text-nova-500 dark:bg-nova-800 dark:text-nova-300">
                <Icon size={18} />
              </span>
              <h3 className="mt-4 font-display text-lg font-semibold text-ink dark:text-white">
                {title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60 dark:text-white/60">
                {body}
              </p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-ink/5 py-8 text-center text-xs text-ink/40 dark:border-white/5 dark:text-white/40">
        NovaPay is a portfolio demo. All balances, cards, and transactions are
        simulated — no real money or banking systems are involved.
      </footer>
    </main>
  );
}
