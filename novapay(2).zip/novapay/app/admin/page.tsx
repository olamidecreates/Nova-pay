import { Users, Wallet, ArrowLeftRight, TrendingUp } from "lucide-react";
import StatCard from "@/components/StatCard";
import { VolumeChart, GrowthChart, MixChart } from "@/components/AdminCharts";
import DemoBadge from "@/components/DemoBadge";

export default function AdminAnalyticsPage() {
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <DemoBadge />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Users} label="Total users" value="1,980" trend={{ positive: true, text: "+22.9%" }} />
        <StatCard icon={Wallet} label="Total wallet balance" value="₦186.4M" trend={{ positive: true, text: "+8.1%" }} />
        <StatCard icon={ArrowLeftRight} label="Transactions this month" value="12,406" trend={{ positive: true, text: "+14.2%" }} />
        <StatCard icon={TrendingUp} label="Transaction volume" value="₦4.2M" trend={{ positive: true, text: "+16.7%" }} />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900 lg:col-span-2">
          <h3 className="mb-1 font-display text-sm font-semibold text-ink dark:text-white">
            Transaction volume
          </h3>
          <p className="mb-2 text-xs text-ink/45 dark:text-white/45">Monthly, in ₦ millions</p>
          <VolumeChart />
        </div>
        <div className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
          <h3 className="mb-1 font-display text-sm font-semibold text-ink dark:text-white">
            Transaction mix
          </h3>
          <p className="mb-2 text-xs text-ink/45 dark:text-white/45">Share by type</p>
          <MixChart />
        </div>
      </div>

      <div className="rounded-2xl border border-ink/5 bg-white p-5 shadow-soft dark:border-white/5 dark:bg-nova-900">
        <h3 className="mb-1 font-display text-sm font-semibold text-ink dark:text-white">
          User growth
        </h3>
        <p className="mb-2 text-xs text-ink/45 dark:text-white/45">New accounts per month</p>
        <GrowthChart />
      </div>
    </div>
  );
}
