"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import AuthShell from "@/components/AuthShell";
import FormField from "@/components/FormField";
import { useWallet } from "@/context/WalletProvider";

export default function SignupPage() {
  const router = useRouter();
  const { login } = useWallet();
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      login();
      setLoading(false);
      router.push("/dashboard");
    }, 900);
  };

  return (
    <AuthShell
      eyebrow="Get started"
      title="Create your account"
      subtitle="Takes less than a minute. This form is simulated — nothing is stored."
    >
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField id="firstName" label="First name" defaultValue="Ipaye" required />
          <FormField id="lastName" label="Last name" defaultValue="Olamide" required />
        </div>
        <FormField
          id="signup-email"
          label="Email address"
          type="email"
          defaultValue="olamide@novapay.demo"
          required
        />
        <FormField id="signup-phone" label="Phone number" type="tel" placeholder="+234 800 000 0000" required />
        <FormField
          id="signup-password"
          label="Create password"
          type="password"
          placeholder="At least 8 characters"
          required
        />
        <label className="flex items-start gap-2 text-xs text-ink/50 dark:text-white/50">
          <input type="checkbox" defaultChecked className="mt-0.5 rounded border-ink/20" />
          I agree to the demo Terms of Service and understand no real account is created.
        </label>
        <button
          type="submit"
          disabled={loading}
          className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-nova-900 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-nova-700 disabled:opacity-70 dark:bg-nova-400 dark:hover:bg-nova-300"
        >
          {loading && <Loader2 size={16} className="animate-spin" />}
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-ink/50 dark:text-white/50">
        Already have an account?{" "}
        <Link href="/login" className="font-semibold text-nova-400">
          Log in
        </Link>
      </p>
    </AuthShell>
  );
}
